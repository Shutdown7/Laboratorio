#!/bin/bash

clear

echo -e "\nParameters: $*"
echo "Number of parameters: $#"
echo -e "Parameter 1: $1\nParameter 2: $2"
echo -e "Script executed as: $0\n"
