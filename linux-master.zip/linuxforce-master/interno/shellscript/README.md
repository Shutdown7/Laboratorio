# Shell Scripts

These scripts are used to present the basic shell script for beginners in my classes

