# Node Storage - CentOS 7
