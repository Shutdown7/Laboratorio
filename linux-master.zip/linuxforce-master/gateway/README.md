# Node Gateway - CentOS 7
