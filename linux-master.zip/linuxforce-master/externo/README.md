# Node Externo - CentOS 6
