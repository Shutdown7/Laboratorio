# Linux Administrator and Linux Engineer Courses

Files used in the Linux Administrator and Linux Engineer courses.<br>
Arquivos utilizados nas aulas dos cursos Linux Administrator e Linux Engineer.
